from tkinter import *
from PIL import Image, ImageTk
from datetime import datetime
from tkinter import ttk, messagebox
import sqlite3

class EmplyeeClass:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1350x700+0+0")
        self.root.title("Inventory Management System | Developed by Usman, Arhum, Areeb and Hadi")
        self.root.config(bg="white")
        self.root.focus_force()
        self.icon_title = Image.open("IMS/images/logo2.png").resize((100, 70))
        self.icon_title = ImageTk.PhotoImage(self.icon_title)
        title = Label(self.root, text="Inventory Management System", image=self.icon_title, compound=LEFT,
                      font=("times new roman", 40, "bold"), bg="black", fg="white", anchor="w", padx=5)
        title.place(x=0, y=0, relwidth=1, height=70)
        self.root.config(bg="white")

        # Clock
        self.lbl_clock = Label(self.root, text="", font=("times new roman", 15), bg="#010c48", fg="white")
        self.lbl_clock.place(x=0, y=70, relwidth=1, height=30)
        self.update_clock()


        # All variables
        self.var_searchby = StringVar()
        self.var_searchtxt = StringVar()

        self.var_emp_id = StringVar()
        self.var_gender = StringVar()
        self.var_contact = StringVar()
        self.var_name = StringVar()
        self.var_dob = StringVar()
        self.var_doj = StringVar()
        self.var_email = StringVar()
        self.var_pass = StringVar()
        self.var_utype = StringVar()
        self.var_salary = StringVar()
        self.var_cnic = StringVar()
        self.var_status=StringVar()

        # search frame
        SearchFrame = LabelFrame(self.root, text="Search Employee", bg="white", font=("goudy old style", 12, "bold"), bd=2, relief=RIDGE)
        SearchFrame.place(x=250, y=100, width=600, height=70)

        cmb_search = ttk.Combobox(SearchFrame, textvariable=self.var_searchby, values=("Select", "Email", "Name", "Contact","Cnic"), state='readonly', justify=CENTER, font=("goudy old style", 15))
        cmb_search.place(x=10, y=10, width=180)
        cmb_search.current(0)

        txt_search = Entry(SearchFrame, textvariable=self.var_searchtxt, font=("goudy old style", 15), bg="lightyellow")
        txt_search.place(x=200, y=10)

        btn_search = Button(SearchFrame, text="Search",command=self.search, font=("goudy old style", 15), bg="#4caf50", fg="white", cursor="hand2")
        btn_search.place(x=410, y=9, width=150, height=30)

        title = Label(self.root, text="Employee Details", font=("goudy old style", 15), bg="#0f4d7d", fg="white")
        title.place(x=50, y=200, width=900)

        lbl_empid = Label(self.root, text="Emp ID", font=("goudy old style", 15), bg="white")
        lbl_empid.place(x=50, y=250)
        lbl_gender = Label(self.root, text="Gender", font=("goudy old style", 15), bg="white")
        lbl_gender.place(x=350, y=330)
        lbl_contact = Label(self.root, text="Contact", font=("goudy old style", 15), bg="white")
        lbl_contact.place(x=50, y=290)

        txt_empid = Entry(self.root, textvariable=self.var_emp_id, font=("goudy old style", 15), bg="lightyellow")
        txt_empid.place(x=150, y=250, width=180)
        txt_empid.config(validate="key", validatecommand=(txt_empid.register(self.validate_int), "%P"))

        cmb_gender = ttk.Combobox(self.root, textvariable=self.var_gender, values=("Select", "Male", "Female", "Other"), state='readonly', justify=CENTER, font=("goudy old style", 15))
        cmb_gender.place(x=500, y=330, width=180)
        cmb_gender.current(0)

        txt_contact = Entry(self.root, textvariable=self.var_contact, font=("goudy old style", 15), bg="lightyellow")
        txt_contact.place(x=150, y=290, width=180)

        lbl_name = Label(self.root, text="Name", font=("goudy old style", 15), bg="white")
        lbl_name.place(x=350, y=250)
        lbl_dob = Label(self.root, text="D.O.B", font=("goudy old style", 15), bg="white")
        lbl_dob.place(x=350, y=290)
        lbl_doj = Label(self.root, text="D.O.J", font=("goudy old style", 15), bg="white")
        lbl_doj.place(x=750, y=290)
        lbl_cnic = Label(self.root, text="CNIC", font=("goudy old style", 15), bg="white")
        lbl_cnic.place(x=750, y=250)

        txt_name = Entry(self.root, textvariable=self.var_name, font=("goudy old style", 15), bg="lightyellow")
        txt_name.place(x=500, y=250, width=180)
        
        txt_dob = Entry(self.root, textvariable=self.var_dob, font=("goudy old style", 15), bg="lightyellow")
        txt_dob.place(x=500, y=290, width=180)
        txt_doj = Entry(self.root, textvariable=self.var_doj, font=("goudy old style", 15), bg="lightyellow")
        txt_doj.place(x=850, y=290, width=150)

        txt_cnic = Entry(self.root, textvariable=self.var_cnic, font=("goudy old style", 15), bg="lightyellow")
        txt_cnic.place(x=850, y=250, width=150)
        txt_cnic.config(validate="key", validatecommand=(txt_cnic.register(self.var_cnic), "%P"))

        lbl_email = Label(self.root, text="Email", font=("goudy old style", 15), bg="white")
        lbl_email.place(x=50, y=330)
        lbl_pass = Label(self.root, text="Password", font=("goudy old style", 15), bg="white")
        lbl_pass.place(x=460, y=370)
        lbl_utype = Label(self.root, text="User Type", font=("goudy old style", 15), bg="white")
        lbl_utype.place(x=750, y=330)

        txt_email = Entry(self.root, textvariable=self.var_email, font=("goudy old style", 15), bg="lightyellow")
        txt_email.place(x=150, y=330, width=180)
        txt_pass = Entry(self.root, textvariable=self.var_pass, font=("goudy old style", 15), bg="lightyellow")
        txt_pass.place(x=560, y=370, width=180)

        cmb_utype = ttk.Combobox(self.root, textvariable=self.var_utype, values=("Admin", "Employee"), state='readonly', justify=CENTER, font=("goudy old style", 15))
        cmb_utype.place(x=850, y=330, width=150)
        cmb_utype.current(0)

        lbl_address = Label(self.root, text="Address", font=("goudy old style", 15), bg="white")
        lbl_address.place(x=50, y=370)
        lbl_salary = Label(self.root, text="Salary", font=("goudy old style", 15), bg="white")
        lbl_salary.place(x=750, y=370)
        lbl_status=Label(self.root, text="Status", font=("goudy old style", 18), bg="white")
        lbl_status.place(x=50,y=450)

        self.txt_adress = Text(self.root, font=("goudy old style", 15), bg="lightyellow")
        self.txt_adress.place(x=150, y=370, width=300, height=60)
        txt_salary = Entry(self.root, textvariable=self.var_salary, font=("goudy old style", 15), bg="lightyellow")
        txt_salary.place(x=850, y=370, width=150)
        cmb_status = ttk.Combobox(self.root, textvariable=self.var_status, values=("Active","Inactive"), state='readonly', justify=CENTER, font=("goudy old style", 15))
        cmb_status.place(x=150, y=450,width=200)
        cmb_status.current(0) 
        # buttons
        btn_add = Button(self.root, text="Save", command=self.add, font=("goudy old style", 15), bg="#2196f3", fg="white", cursor="hand2")
        btn_add.place(x=500, y=450, width=110, height=28)
        btn_update = Button(self.root, text="Update", command=self.update, font=("goudy old style", 15), bg="#4caf50", fg="white", cursor="hand2")
        btn_update.place(x=620, y=450, width=110, height=28)
        btn_delete = Button(self.root, text="Delete", command=self.delete, font=("goudy old style", 15), bg="#f44336", fg="white", cursor="hand2")
        btn_delete.place(x=740, y=450, width=110, height=28)
        btn_clear = Button(self.root, text="Clear", command=self.clear, font=("goudy old style", 15), bg="#607d8b", fg="white", cursor="hand2")
        btn_clear.place(x=860, y=450, width=110, height=28)

        # Employee Details
        emp_frame = Frame(self.root, bd=3, relief=RIDGE)
        emp_frame.place(x=0, y=500, relwidth=1, height=150)

        scrolly = Scrollbar(emp_frame, orient=VERTICAL)
        scrollx = Scrollbar(emp_frame, orient=HORIZONTAL)

        self.EmplyeeTable = ttk.Treeview(emp_frame, columns=("empid", "name", "email", "gender", "contact", "dob", "doj", "pass", "utype", "address", "salary","cnic","status"), yscrollcommand=scrolly.set, xscrollcommand=scrollx.set)
        scrollx.pack(side=BOTTOM, fill=X)
        scrolly.pack(side=RIGHT, fill=Y)
        scrollx.config(command=self.EmplyeeTable.xview)
        scrolly.config(command=self.EmplyeeTable.yview)
        self.EmplyeeTable.heading("empid", text="EMP ID")
        self.EmplyeeTable.heading("name", text="Name")
        self.EmplyeeTable.heading("email", text="Email")
        self.EmplyeeTable.heading("gender", text="Gender")
        self.EmplyeeTable.heading("contact", text="Contact")
        self.EmplyeeTable.heading("dob", text="D.O.B")
        self.EmplyeeTable.heading("doj", text="D.O.J")
        self.EmplyeeTable.heading("pass", text="Password")
        self.EmplyeeTable.heading("utype", text="User Type")
        self.EmplyeeTable.heading("address", text="Address")
        self.EmplyeeTable.heading("salary", text="Salary")
        self.EmplyeeTable.heading("cnic", text="CNIC")
        self.EmplyeeTable.heading("status", text="Status")
        self.EmplyeeTable["show"] = "headings"

        self.EmplyeeTable.column("empid", width=90)
        self.EmplyeeTable.column("name", width=100)
        self.EmplyeeTable.column("email", width=100)
        self.EmplyeeTable.column("gender", width=100)
        self.EmplyeeTable.column("contact", width=100)
        self.EmplyeeTable.column("dob", width=100)
        self.EmplyeeTable.column("doj", width=100)
        self.EmplyeeTable.column("pass", width=100)
        self.EmplyeeTable.column("utype", width=100)
        self.EmplyeeTable.column("address", width=100)
        self.EmplyeeTable.column("salary", width=100)
        self.EmplyeeTable.column("cnic", width=100)
        self.EmplyeeTable.column("status", width=100)
        self.EmplyeeTable.pack(fill=BOTH, expand=1)
        self.EmplyeeTable.bind("<ButtonRelease-1>",self.get_data)
        self.show()
    # Footer
        lbl_footer = Label(self.root,
                           text="IMS- Inventory Management System | Developed by Usman, Arhum, Areeb & Hadi\nFor any Technical Issue Contact: +923362748573",
                           font=("times new roman", 12), bg="#010c48", fg="white")
        lbl_footer.pack(side=BOTTOM, fill=X)
    # Method to validate if the input is an integer
    def validate_int(self, value):
        if value.isdigit():
            return True
        elif value == "":
            return True
        else:
            return False

   
    def add(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
            if self.var_emp_id.get() == "":
                messagebox.showerror("Error", "Employee ID must be required", parent=self.root)
            elif self.var_cnic.get() == "":
                messagebox.showerror("Error", "CNIC must be required", parent=self.root)
            else:
                cur.execute("SELECT * FROM Emplyee WHERE empid=?", (self.var_emp_id.get(),))
                row_empid = cur.fetchone()
                cur.execute("SELECT * FROM Emplyee WHERE cnic=?", (self.var_cnic.get(),))
                row_cnic = cur.fetchone()
                if row_empid:
                    messagebox.showerror("Error", "This Employee ID is already assigned. Please try a different one.", parent=self.root)
                elif row_cnic:
                    messagebox.showerror("Error", "This CNIC is already assigned to another employee. Please enter a different CNIC.", parent=self.root)
                else:
                    # Continue with insert operation
                    cur.execute("INSERT INTO Emplyee (empid, name, email, gender, contact, dob, doj, pass, utype, address, salary, cnic, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", (
                                        self.var_emp_id.get(),
                                        self.var_name.get(),
                                        self.var_email.get(),
                                        self.var_gender.get(),
                                        self.var_contact.get(),
                                        self.var_dob.get(),
                                        self.var_doj.get(),
                                        self.var_pass.get(),
                                        self.var_utype.get(),
                                        self.txt_adress.get('1.0', END),
                                        self.var_salary.get(),
                                        self.var_cnic.get(),
                                        self.var_status.get()
                    ))
                    con.commit()
                    messagebox.showinfo("Success", "Employee Added Successfully", parent=self.root)
                    self.show()    
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

    def show(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
            cur.execute("SELECT * FROM Emplyee")
            rows = cur.fetchall()
            self.EmplyeeTable.delete(*self.EmplyeeTable.get_children())
            for row in rows:
                self.EmplyeeTable.insert('', END, values=row)
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

    def get_data(self, ev):
        cursor_row = self.EmplyeeTable.focus()
        content = self.EmplyeeTable.item(cursor_row)
        row = content['values']
        self.var_emp_id.set(row[0])
        self.var_name.set(row[1])
        self.var_email.set(row[2])
        self.var_gender.set(row[3])
        self.var_contact.set(row[4])
        self.var_dob.set(row[5])
        self.var_doj.set(row[6])
        self.var_pass.set(row[7])
        self.var_utype.set(row[8])
        self.txt_adress.delete('1.0', END)
        self.txt_adress.insert(END, row[9])
        self.var_salary.set(row[10])
        self.var_cnic.set(row[11])
        self.var_status.set(row[12])

    def update(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
            if self.var_emp_id.get() == "":
                messagebox.showerror("Error", "Employee ID must be required", parent=self.root)
            elif self.var_cnic.get() == "":
                messagebox.showerror("Error", "CNIC must be required", parent=self.root)
            else:
                cur.execute("SELECT * FROM Emplyee WHERE empid=? AND cnic!=?", (self.var_emp_id.get(), self.var_cnic.get()))
                row = cur.fetchone()
                if row:
                    messagebox.showerror("Error", "This Employee ID is already assigned. Please try a different one.", parent=self.root)
                else:
                    cur.execute("UPDATE Emplyee SET name=?, email=?, gender=?, contact=?, dob=?, doj=?, pass=?, utype=?, address=?, salary=?, cnic=?, status=? WHERE empid=?", (
                                        self.var_name.get(),
                                        self.var_email.get(),
                                        self.var_gender.get(),
                                        self.var_contact.get(),
                                        self.var_dob.get(),
                                        self.var_doj.get(),
                                        self.var_pass.get(),
                                        self.var_utype.get(),
                                        self.txt_adress.get('1.0', END),
                                        self.var_salary.get(),
                                        self.var_cnic.get(),
                                        self.var_status.get(),
                                        self.var_emp_id.get()
                    ))
                    con.commit()
                    messagebox.showinfo("Success", "Employee Updated Successfully", parent=self.root)
                    self.show()    
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

    def delete(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
            if self.var_emp_id.get() == "":
                messagebox.showerror("Error", "Employee ID must be required", parent=self.root)
            else:
                cur.execute("DELETE FROM Emplyee WHERE empid=?", (self.var_emp_id.get(),))
                con.commit()
                messagebox.showinfo("Success", "Employee Deleted Successfully", parent=self.root)
                self.show()    
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

    def clear(self):
        self.var_emp_id.set("")
        self.var_name.set("")
        self.var_email.set("")
        self.var_gender.set("")
        self.var_contact.set("")
        self.var_dob.set("")
        self.var_doj.set("")
        self.var_pass.set("")
        self.var_utype.set("")
        self.txt_adress.delete('1.0', END)
        self.var_salary.set("")
        self.var_cnic.set("")
        self.var_status.set("")
        self.var_searchby.set("")
        self.var_searchtxt.set("")
        self.show()

    def search(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
           if self.var_searchby.get() == "Select":
            messagebox.showerror("Error", "Please select category to search", parent=self.root)
           elif self.var_searchtxt.get() == "":
            messagebox.showerror("Error", "Search input required", parent=self.root)
           else:
            if self.var_searchby.get() == "CNIC":
                # Search by CNIC
                cur.execute(f"SELECT * FROM Emplyee WHERE cnic LIKE ?", ('%' + self.var_searchtxt.get() + '%',))
            else:
                # Search by other fields
                cur.execute(f"SELECT * FROM Emplyee WHERE {self.var_searchby.get()} LIKE ?", ('%' + self.var_searchtxt.get() + '%',))
            rows = cur.fetchall()
            if len(rows) != 0:
                self.EmplyeeTable.delete(*self.EmplyeeTable.get_children())
                for row in rows:
                    self.EmplyeeTable.insert('', END, values=row)
            else:
                messagebox.showerror("Error", "No record found", parent=self.root)
        except Exception as ex:
                messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)
    def update_clock(self):
        current_time = datetime.now().strftime(
            "Welcome to Inventory Management System\t\t Date: %d-%m-%Y  Time: %H:%M:%S")
        self.lbl_clock.config(text=current_time)
        self.root.after(1000, self.update_clock)
    
root = Tk()
obj = EmplyeeClass(root)
root.mainloop()
