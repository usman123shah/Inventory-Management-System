from tkinter import *
from PIL import Image, ImageTk
from datetime import datetime
from employee import EmplyeeClass
from supplier import supplierClass
from category import categoryClass
from product import productClass
from sales import SalesApp  # Import the SalesApp class
import sqlite3
from tkinter import messagebox

class IMS:
    def __init__(self, root, username):
        self.username = username
        self.root = root
        self.root.geometry("1350x700+0+0")
        self.root.title("Inventory Management System | Developed by Usman, Arhum, Areeb and Hadi")

        # Title
        self.icon_title = Image.open("IMS/images/logo2.png").resize((100, 70))
        self.icon_title = ImageTk.PhotoImage(self.icon_title)
        title = Label(self.root, text="Inventory Management System", image=self.icon_title, compound=LEFT,
                      font=("times new roman", 40, "bold"), bg="black", fg="white", anchor="w", padx=5)
        title.place(x=0, y=0, relwidth=1, height=70)
        self.root.config(bg="white")

        # Clock
        self.lbl_clock = Label(self.root, text="", font=("times new roman", 15), bg="#010c48", fg="white")
        self.lbl_clock.place(x=0, y=70, relwidth=1, height=30)
        self.update_clock()

        # Left Menu
        self.MenuLogo = Image.open("IMS/images/menu_im.png").resize((200, 200))
        self.MenuLogo = ImageTk.PhotoImage(self.MenuLogo)

        LeftMenu = Frame(self.root, bd=2, relief=RIDGE, bg="white")
        LeftMenu.place(x=0, y=102, width=200, height=565)

        lbl_menulogo = Label(LeftMenu, image=self.MenuLogo)
        lbl_menulogo.pack(side=TOP, fill=X)

        self.icon_side = Image.open("IMS/images/side.png").resize((30, 30))
        self.icon_side = ImageTk.PhotoImage(self.icon_side)

        lbl_menu = Label(LeftMenu, text="Menu", font=("times new roman", 20), bg="#009688")
        lbl_menu.pack(side=TOP, fill=X)

        btn_employee = Button(LeftMenu, text="Employee", command=self.emplyee, image=self.icon_side,
                              compound=LEFT, padx=5, anchor="w", font=("times new roman", 20, "bold"), bg="white",
                              bd=3, cursor="hand2")
        btn_employee.pack(side=TOP, fill=X)
        btn_supplier = Button(LeftMenu, text="Supplier", command=self.supplier, image=self.icon_side,
                              compound=LEFT, padx=5, anchor="w", font=("times new roman", 20, "bold"), bg="white",
                              bd=3, cursor="hand2")
        btn_supplier.pack(side=TOP, fill=X)
        btn_category = Button(LeftMenu, text="Category", command=self.category, image=self.icon_side,
                              compound=LEFT, padx=5, anchor="w", font=("times new roman", 20, "bold"), bg="white",
                              bd=3, cursor="hand2")
        btn_category.pack(side=TOP, fill=X)
        btn_product = Button(LeftMenu, text="Product", command=self.product, image=self.icon_side,
                             compound=LEFT, padx=5, anchor="w", font=("times new roman", 20, "bold"), bg="white",
                             bd=3, cursor="hand2")
        btn_product.pack(side=TOP, fill=X)
        btn_sales = Button(LeftMenu, text="Sales", command=self.sales, image=self.icon_side,
                           compound=LEFT, padx=5, anchor="w", font=("times new roman", 20, "bold"), bg="white",
                           bd=3, cursor="hand2")
        btn_sales.pack(side=TOP, fill=X)
        btn_exit = Button(LeftMenu, text="Exit", image=self.icon_side, compound=LEFT, padx=5, anchor="w",
                          font=("times new roman", 20, "bold"), bg="white", bd=3, cursor="hand2",
                          command=self.root.destroy)
        btn_exit.pack(side=TOP, fill=X)
        # Logout Button
        self.btn_logout = Button(self.root, text="Logout", font=("times new roman", 15, "bold"), bg="yellow",
                                 cursor="hand2", command=self.logout)
        self.btn_logout.place(x=900, y=20, height=30, width=100)

        # Exit Button

        RIGHTMenu = Frame(self.root, bd=2, relief=RIDGE, bg="white")
        RIGHTMenu.place(x=700, y=102, width=320, height=565)
        # Content Frame
        content_frame = Frame(self.root, bd=2, relief=RIDGE, bg="white")
        content_frame.place(x=220, y=120, width=450, height=480)

        # Labels in Content Frame
        self.lbl_emplyee = Label(RIGHTMenu, text="Total Employee\n[ 0 ]", bd=5, relief=RIDGE, bg="#33bbf9",
                                   fg="white", font=("goudy old style", 20, "bold"))
        self.lbl_emplyee.place(x=20, y=20, height=100, width=290)

        self.lbl_supplier = Label(RIGHTMenu, text="Total Supplier\n[ 0 ]", bd=5, relief=RIDGE, bg="#ff5722",
                                  fg="white", font=("goudy old style", 20, "bold"))
        self.lbl_supplier.place(x=20, y=140, height=100, width=290)

        self.lbl_category = Label(RIGHTMenu, text="Total Category\n[ 0 ]", bd=5, relief=RIDGE, bg="#009688",
                                  fg="white", font=("goudy old style", 20, "bold"))
        self.lbl_category.place(x=20, y=260, height=100, width=290)

        self.lbl_product = Label(RIGHTMenu, text="Total Product\n[ 0 ]", bd=5, relief=RIDGE, bg="#607d8b",
                                 fg="white", font=("goudy old style", 20, "bold"))
        self.lbl_product.place(x=20, y=380, height=100, width=290)

        # PNG Image
        self.center_image_frame = Frame(content_frame, bg="white")
        self.center_image_frame.place(relx=0.5, rely=0.5, anchor=CENTER)

        self.center_image = Image.open("IMS/images/download.jpg").resize((450, 480))
        self.center_image = ImageTk.PhotoImage(self.center_image)

        self.lbl_center_image = Label(self.center_image_frame, image=self.center_image, bd=5, relief=RIDGE)
        self.lbl_center_image.pack()

        # Footer
        lbl_footer = Label(self.root,
                           text="IMS- Inventory Management System | Developed by Usman, Arhum, Areeb & Hadi\nFor any Technical Issue Contact: +923362748573",
                           font=("times new roman", 12), bg="#010c48", fg="white")
        lbl_footer.pack(side=BOTTOM, fill=X)

        self.update_content()

    def emplyee(self):
        self.new_win = Toplevel(self.root)
        self.new_obj = EmplyeeClass(self.new_win)

    def supplier(self):
        self.new_win = Toplevel(self.root)
        self.new_obj = supplierClass(self.new_win)

    def category(self):
        self.new_win = Toplevel(self.root)
        self.new_obj = categoryClass(self.new_win)

    def product(self):
        self.new_win = Toplevel(self.root)
        self.new_obj = productClass(self.new_win)

    def sales(self):
        # Open the sales window
        self.new_win = Toplevel(self.root)
        self.new_obj = SalesApp(self.new_win)

    def logout(self):
        # Perform logout operations here, such as closing any open windows or clearing session data
        messagebox.showinfo("Logout", "You have been logged out successfully!")

    def update_content(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
            cur.execute("select * from product")
            product = cur.fetchall()
            self.lbl_product.config(text=f'Total Product\n[ {str(len(product))} ]')

            cur.execute("select * from supplier")
            supplier = cur.fetchall()
            self.lbl_supplier.config(text=f'Total Supplier\n[ {str(len(supplier))} ]')

            cur.execute("select * from Emplyee")
            Emplyee = cur.fetchall()
            self.lbl_emplyee.config(text=f'Total Employee\n[ {str(len(Emplyee))} ]')

            cur.execute("select * from Category")
            Category = cur.fetchall()
            self.lbl_category.config(text=f'Total Category\n[ {str(len(Category))} ]')
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

    def update_sales(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
            cur.execute("SELECT COUNT(DISTINCT id) FROM sales")
            total_sales = cur.fetchone()[0]
            self.lbl_sales.config(text=f'Total Sales\n[ {str(total_sales)} ]')

        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)
        finally:
            con.close()

    def update_clock(self):
        current_time = datetime.now().strftime(
        "Welcome to Inventory Management System\t\t Date: %d-%m-%Y  Time: %H:%M:%S")
        self.lbl_clock.config(text=current_time)
        self.root.after(1000, self.update_clock)

if __name__ == "__main__":
    root = Tk()
    obj = IMS(root)
    root.mainloop()
