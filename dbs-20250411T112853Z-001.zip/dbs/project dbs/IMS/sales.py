from tkinter import *
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
from fpdf import FPDF
import time
from PIL import Image, ImageTk

class SalesApp:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1350x700+0+0")
        self.root.title("Sales App")

        # Title
        self.icon_title = Image.open("IMS/images/logo2.png").resize((100, 70))
        self.icon_title = ImageTk.PhotoImage(self.icon_title)
        title = Label(self.root, text="Inventory Management System", image=self.icon_title, compound=LEFT,
                      font=("times new roman", 40, "bold"), bg="black", fg="white", anchor="w", padx=5)
        title.pack(side=TOP, fill=X)

        # Clock
        self.lbl_clock = Label(self.root, text="", font=("times new roman", 15), bg="#010c48", fg="white")
        self.lbl_clock.pack(side=TOP, fill=X)
        self.update_clock()

        # Load the image
        self.sales_image = Image.open("IMS/images/sires.jpg")
        self.sales_photo = ImageTk.PhotoImage(self.sales_image)

        # Create a label to display the image
        self.image_label = Label(root, image=self.sales_photo)
        self.image_label.pack(side=LEFT, padx=20, pady=20)

        self.var_product = StringVar()
        self.var_customer_name = StringVar()
        self.var_quantity = IntVar()
        self.var_discount = DoubleVar()
        self.var_original_price = DoubleVar()
        self.var_discounted_price = DoubleVar()
        self.var_total_price = DoubleVar()
    
        # Product selection
        frame_product = Frame(root)
        frame_product.pack(side=LEFT, padx=20, pady=20)

        Label(frame_product, text="Select Product:", font=("times new roman", 14)).grid(row=0, column=0, padx=10, pady=10)
        self.cmb_product = ttk.Combobox(frame_product, textvariable=self.var_product, state='readonly', width=25)
        self.cmb_product.grid(row=0, column=1, padx=10, pady=10)

        self.populate_product_combobox()

        # Customer name
        Label(frame_product, text="Customer Name:", font=("times new roman", 14)).grid(row=1, column=0, padx=5, pady=10)
        Entry(frame_product, textvariable=self.var_customer_name, width=30).grid(row=1, column=1, padx=5, pady=10)

        # Quantity
        Label(frame_product, text="Quantity:", font=("times new roman", 14)).grid(row=2, column=0, padx=10, pady=10)
        Entry(frame_product, textvariable=self.var_quantity, width=10).grid(row=2, column=1, padx=10, pady=10)

        # Discount
        Label(frame_product, text="Discount (%):", font=("times new roman", 14)).grid(row=3, column=0, padx=10, pady=10)
        Entry(frame_product, textvariable=self.var_discount, width=10).grid(row=3, column=1, padx=10, pady=10)

        # Sale button
        Button(frame_product, text="Sale", command=self.finalize_sale, width=15).grid(row=4, column=0, columnspan=2, padx=10, pady=10)



    def populate_product_combobox(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
            cur.execute("SELECT name FROM product")
            rows = cur.fetchall()
            products = [row[0] for row in rows]
            self.cmb_product['values'] = products
        except Exception as ex:
            messagebox.showerror("Error", f"Error fetching product data: {str(ex)}", parent=self.root)
        finally:
            con.close()

    def finalize_sale(self):
        product = self.var_product.get()
        customer_name = self.var_customer_name.get()
        if not product:
            messagebox.showerror("Error", "Please select a product", parent=self.root)
            return
        if not customer_name:
            messagebox.showerror("Error", "Please enter customer name", parent=self.root)
            return

        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
            # Fetch data of the selected product from the database
            cur.execute("SELECT price, qty FROM product WHERE name=?", (product,))
            row = cur.fetchone()
            if row:
                price = float(row[0])
                quantity = int(row[1])
                if quantity < self.var_quantity.get():
                    messagebox.showerror("Error", "Insufficient quantity available", parent=self.root)
                    return

                self.var_original_price.set(price)
                self.var_discounted_price.set(price * (1 - (self.var_discount.get() / 100)))
                total_price = self.var_discounted_price.get() * self.var_quantity.get()
                self.var_total_price.set(total_price)

                # Open live bill window
                self.show_live_bill(product, customer_name, self.var_quantity.get(), self.var_original_price.get(), 
                                    self.var_discounted_price.get(), self.var_total_price.get(), con, cur)

            else:
                messagebox.showerror("Error", "Product Not Found", parent=self.root)
        except Exception as ex:
            messagebox.showerror("Error", f"Error: {str(ex)}", parent=self.root)

    def show_live_bill(self, product, customer_name, quantity, original_price, discounted_price, total_price, con, cur):
        live_bill_window = Toplevel(self.root)
        live_bill_window.title("Live Bill")

        Label(live_bill_window, text="Live Bill", font=('Helvetica', 16, 'bold')).pack(pady=10)

        # Display live bill information
        Label(live_bill_window, text=f"Product: {product}").pack()
        Label(live_bill_window, text=f"Customer Name: {customer_name}").pack()
        Label(live_bill_window, text=f"Quantity: {quantity}").pack()
        Label(live_bill_window, text=f"Original Price: {original_price}").pack()
        Label(live_bill_window, text=f"Discounted Price: {discounted_price}").pack()
        Label(live_bill_window, text=f"Total Price: {total_price}").pack()

        def finalize_and_generate_pdf():
            live_bill_window.destroy()
            # Ask to generate PDF
            if messagebox.askyesno("Generate PDF", "Do you want to generate PDF of the bill?"):
                timestamp = time.strftime("%Y%m%d%H%M%S")
                pdf_filename = f"Sales_Bill_{timestamp}.pdf"
                self.generate_pdf(pdf_filename, product, customer_name, quantity, original_price, discounted_price, total_price)
                # Update quantity in the database after sale
                new_quantity = quantity - self.var_quantity.get()
                cur.execute("UPDATE product SET qty=? WHERE name=?", (new_quantity, product))
                con.commit()
            con.close()

        Button(live_bill_window, text="Finalize Sale and Generate PDF", command=finalize_and_generate_pdf).pack(pady=10)


    def generate_pdf(self, pdf_filename, product, customer_name, quantity, original_price, discounted_price, total_price):
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.cell(200, 10, txt="Sales Bill", ln=True, align="C")
        pdf.cell(200, 10, txt="", ln=True, align="C")
        pdf.cell(200, 10, txt=f"Product: {product}", ln=True, align="L")
        pdf.cell(200, 10, txt=f"Customer Name: {customer_name}", ln=True, align="L")
        pdf.cell(200, 10, txt=f"Quantity: {quantity}", ln=True, align="L")
        pdf.cell(200, 10, txt=f"Original Price: {original_price}", ln=True, align="L")
        pdf.cell(200, 10, txt=f"Discounted Price: {discounted_price}", ln=True, align="L")
        pdf.cell(200, 10, txt=f"Total Price: {total_price}", ln=True, align="L")
        pdf.output(pdf_filename)

    def update_clock(self):
        current_time = datetime.now().strftime(
        "Welcome to Inventory Management System\t\t Date: %d-%m-%Y  Time: %H:%M:%S")
        self.lbl_clock.config(text=current_time)
        self.root.after(1000, self.update_clock)


if __name__ == "__main__":
    root = Tk()
    obj = SalesApp(root)
    root.mainloop()
