import sqlite3

def create_db():
    con = sqlite3.connect(database=r'ims.db')
    cur = con.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS employee(empid INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, gender TEXT, contact TEXT, dob TEXT, doj TEXT, pass TEXT, utype TEXT, address TEXT, salary TEXT, cnic TEXT)")
    con.commit()
    cur.execute("CREATE TABLE IF NOT EXISTS emplyee(empid INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, gender TEXT, contact TEXT, dob TEXT, doj TEXT, pass TEXT, utype TEXT, address TEXT, salary TEXT, cnic Text)")
  #  cur.execute("ALTER TABLE Emplyee ADD COLUMN status TEXT")
    con.commit()
    cur.execute("CREATE TABLE IF NOT EXISTS supplier(invoice INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT,  contact TEXT, desc TEXT)")
   # cur.execute("ALTER TABLE supplier ADD COLUMN status TEXT")
    cur.execute("ALTER TABLE supplier ADD COLUMN prev TEXT")
    con.commit()
    
    cur.execute("CREATE TABLE IF NOT EXISTS category(cid INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)")
    con.commit()

    cur.execute("CREATE TABLE IF NOT EXISTS product(pid INTEGER PRIMARY KEY AUTOINCREMENT, Supplier TEXT,  Category TEXT, name TEXT, price TEXT, qty TEXT, status TEXT)")
    con.commit()

    cur.execute(" CREATE TABLE IF NOT EXISTS sales (sale_id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,customer_name TEXT,quantity INTEGER,sale_date TEXT,FOREIGN KEY (product_id) REFERENCES product (pid))")
    con.commit()


create_db()
 