from tkinter import *
from PIL import Image, ImageTk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
class categoryClass:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1350x700+0+0")
        self.root.title("Inventory Management System | Developed by Usman, Arhum, Areeb and Hadi")
        self.root.config(bg="white")
        self.root.focus_force()
        # Title
        self.icon_title = Image.open("IMS/images/logo2.png").resize((100, 70))
        self.icon_title = ImageTk.PhotoImage(self.icon_title)
        title = Label(self.root, text="Inventory Management System", image=self.icon_title, compound=LEFT,
                      font=("times new roman", 40, "bold"), bg="black", fg="white", anchor="w", padx=5)
        title.place(x=0, y=0, relwidth=1, height=70)
        self.root.config(bg="white")

        # Clock
        self.lbl_clock = Label(self.root, text="", font=("times new roman", 15), bg="#010c48", fg="white")
        self.lbl_clock.place(x=0, y=70, relwidth=1, height=30)
        self.update_clock()
        #=======variables
        self.var_cat_id = StringVar()
        self.var_name = StringVar()
        #==============title===============================
        lbl_title = Label(self.root, text="Manage Product Category", font=("goudy old style", 30), bg="#0f4d7d", fg="white", relief=RIDGE)
        lbl_title.pack(side=TOP, fill=X, padx=10, pady=110)

        lbl_name = Label(self.root, text="Enter Category Name", font=("goudy old style", 30), bg="white")
        lbl_name.place(x=50, y=200)
        txt_name = Entry(self.root, textvariable=self.var_name, font=("goudy old style", 18), bg="lightyellow")
        txt_name.place(x=50, y=270, width=300)

        btn_add = Button(self.root, text="ADD", command=self.add, font=("goudy old style", 18), bg="#4caf50", fg="white", cursor="hand2")
        btn_add.place(x=50, y=350, width=130, height=30)
        btn_delete = Button(self.root, text="Delete", command=self.delete, font=("goudy old style", 18), bg="red", fg="white", cursor="hand2")
        btn_delete.place(x=200, y=350, width=130, height=30)

        # Category Details
        cat_frame = Frame(self.root, bd=3, relief=RIDGE)
        cat_frame.place(x=0, y=500, relwidth=1, height=150)

        scrolly = Scrollbar(cat_frame, orient=VERTICAL)
        scrollx = Scrollbar(cat_frame, orient=HORIZONTAL)

        self.category_Table = ttk.Treeview(cat_frame, columns=("cid", "name"), yscrollcommand=scrolly.set, xscrollcommand=scrollx.set)
        scrollx.pack(side=BOTTOM, fill=X)
        scrolly.pack(side=RIGHT, fill=Y)
        scrollx.config(command=self.category_Table.xview)
        scrolly.config(command=self.category_Table.yview)
        self.category_Table.heading("cid", text="Category ID")
        self.category_Table.heading("name", text="Name")
        self.category_Table["show"] = "headings"

        self.category_Table.column("cid", width=50)
        self.category_Table.column("name", width=50)
        self.category_Table.pack(fill=BOTH, expand=1)
        self.category_Table.bind("<ButtonRelease-1>", self.get_data)
        self.show()

        # Load image
        self.im1 = Image.open("IMS/images/cat.jpg")
        self.im1 = self.im1.resize((550, 300))
        self.im1 = ImageTk.PhotoImage(self.im1)

        self.lbl_im1 = Label(self.root, image=self.im1, bd=2, relief=RIDGE)
        self.lbl_im1.place(x=500, y=180, width=500, height=250)
# Footer
        lbl_footer = Label(self.root,
                           text="IMS- Inventory Management System | Developed by Usman, Arhum, Areeb & Hadi\nFor any Technical Issue Contact: +923362748573",
                           font=("times new roman", 12), bg="#010c48", fg="white")
        lbl_footer.pack(side=BOTTOM, fill=X)
    # add method
    def add(self):
        print("Add method called")
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
            if self.var_name.get() == "":
                messagebox.showerror("Error", "Category must be required", parent=self.root)
            else:
                cur.execute("SELECT * FROM category WHERE name=?", (self.var_name.get(),))
                row = cur.fetchone()
                if row is not None:
                    messagebox.showerror("Error", "Category already present, try different", parent=self.root)
                else:
                    cur.execute("INSERT INTO category (name) VALUES (?)", (self.var_name.get(),))
                    con.commit()
                    messagebox.showinfo("Success", "Category Added Successfully", parent=self.root)
                    self.show()
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

    def show(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
            cur.execute("SELECT * FROM category")
            rows = cur.fetchall()
            self.category_Table.delete(*self.category_Table.get_children())
            for row in rows:
                self.category_Table.insert('', END, values=row)
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)

    def get_data(self, ev):
        f = self.category_Table.focus()
        content = self.category_Table.item(f)
        row = content['values']
        self.var_cat_id.set(row[0])
        self.var_name.set(row[1])

    def delete(self):
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        try:
            if self.var_cat_id.get() == "":
                messagebox.showerror("Error", "Category must be required", parent=self.root)
            else:
                cur.execute("SELECT * FROM category WHERE cid=?", (self.var_cat_id.get(),))
                row = cur.fetchone()
                if row is None:
                    messagebox.showerror("Error", "Invalid Category", parent=self.root)
                else:
                    op = messagebox.askyesno("Confirm", "Do you really want to delete?", parent=self.root)
                    if op:
                        cur.execute("DELETE FROM category WHERE cid=?", (self.var_cat_id.get(),))
                        con.commit()
                        messagebox.showinfo("Delete", "Category Deleted Successfully", parent=self.root)
                        self.show()
                        self.var_cat_id.set("")
                        self.var_name.set("")
        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)
    def update_clock(self):
        current_time = datetime.now().strftime(
            "Welcome to Inventory Management System\t\t Date: %d-%m-%Y  Time: %H:%M:%S")
        self.lbl_clock.config(text=current_time)
        self.root.after(1000, self.update_clock)

if __name__ == "__main__":
    root = Tk()
    obj = categoryClass(root)
    root.mainloop()
