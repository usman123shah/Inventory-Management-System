from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
from dashboard import IMS  # Import the IMS class from the dashboard file

class LoginPage:
    def __init__(self, root):
        self.root = root
        self.root.title("Login Page")
        self.root.geometry("400x150")

        self.users = {
            "admin": "password",  # Sample admin credentials
            "user1": "123456",
            "user2": "abc123"
        }

        self.username = StringVar()
        self.password = StringVar()

        # Load the image
        self.login_img = Image.open("IMS\images\im2.png")
        self.login_img = self.login_img.resize((100, 100))
        self.login_img = ImageTk.PhotoImage(self.login_img)

        # Label to display the image
        self.img_label = Label(root, image=self.login_img)
        self.img_label.grid(row=0, column=0, rowspan=3, padx=10, pady=10)

        # Username Entry
        Label(root, text="Username:").grid(row=0, column=1, padx=10, pady=10)
        Entry(root, textvariable=self.username).grid(row=0, column=2, padx=10, pady=10)

        # Password Entry
        Label(root, text="Password:").grid(row=1, column=1, padx=10, pady=10)
        Entry(root, textvariable=self.password, show="*").grid(row=1, column=2, padx=10, pady=10)

        # Login Button
        Button(root, text="Login", command=self.login).grid(row=2, column=1, columnspan=2, padx=10, pady=10)

    def login(self):
        username = self.username.get()
        password = self.password.get()

        # Check if username exists and password matches
        if username in self.users and self.users[username] == password:
            # Check if the user is an admin
            if username == 'admin':
                messagebox.showinfo("Login Successful", "Welcome to the Dashboard!")
                self.root.destroy()  # Close the login window
                root = Tk()
                dashboard = IMS(root, username)  # Open the dashboard with the username
                root.mainloop()
            else:
                messagebox.showerror("Login Failed", "Only admins can log in.")
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")

if __name__ == "__main__":
    root = Tk()
    login_page = LoginPage(root)
    root.mainloop()
